htmlSuite('core-overlay', function() {
  htmlTest('html/core-overlay-basic.html');
  htmlTest('html/core-overlay-positioning.html');
  htmlTest('html/core-overlay-positioning-margin.html');
  htmlTest('html/core-overlay-scroll.html');
  htmlTest('html/core-overlay-quick-close.html');
});
